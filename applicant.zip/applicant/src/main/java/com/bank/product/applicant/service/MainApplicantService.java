package com.bank.product.applicant.service;

import java.util.List;
import java.util.Optional;

import com.bank.product.applicant.entity.MainApplicant;

public interface MainApplicantService {

	void registerApplicant(MainApplicant applicant);
	
	MainApplicant getApplicantById(int applicantId);
	
	MainApplicant updateApplicantById(MainApplicant updateData);
	
	boolean deleteByApplicantId(int applicantId);
	
	List<MainApplicant> getAllApplicants();
	
	
	
}
