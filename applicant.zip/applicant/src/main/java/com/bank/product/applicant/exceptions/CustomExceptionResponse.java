package com.bank.product.applicant.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestController
@ControllerAdvice
public class CustomExceptionResponse extends ResponseEntityExceptionHandler {

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ExceptionResponse> handleExceptionInternal(Exception ex,  WebRequest request) {
		ExceptionResponse exception = new ExceptionResponse(request.getDescription(true), new Date(), ex.getMessage());
				return new ResponseEntity<ExceptionResponse>(exception,HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
