package com.bank.product.applicant.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bank.product.applicant.entity.MainApplicant;

@Repository
public interface MainApplicantRepository extends JpaRepository<MainApplicant, Integer> {
	

}
