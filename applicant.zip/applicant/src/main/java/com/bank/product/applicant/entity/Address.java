package com.bank.product.applicant.entity;

public class Address {

}
