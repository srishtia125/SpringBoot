package com.bank.product.applicant.service.impl;

import java.util.List;

import com.bank.product.applicant.entity.MainApplicant;
import com.bank.product.applicant.service.MainApplicantService;

public class MainApplicantServiceImpl implements MainApplicantService {

	@Override
	public void registerApplicant(MainApplicant applicant) {

	}

	@Override
	public MainApplicant getApplicantById(int applicantId) {
		return null;
	}

	@Override
	public MainApplicant updateApplicantById(MainApplicant updateData) {
		return null;
	}

	@Override
	public boolean deleteByApplicantId(int applicantId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<MainApplicant> getAllApplicants() {
		// TODO Auto-generated method stub
		return null;
	}

}
